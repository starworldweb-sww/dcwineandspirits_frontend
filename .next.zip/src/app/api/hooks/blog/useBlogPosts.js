import { useMutation, useQuery } from "@tanstack/react-query";
import { blogKeys } from "@/libs/queryKeys";       // jahan tumne blogKeys define kiya
import { blogService } from "../../services/blogService"; // apna actual path daal dena
import { getPostsAction } from "@/app/blogs/actions";

export const useGetAllPosts = (params = {}, options = {}) => {
  return useQuery({
    queryKey: blogKeys.posts(params),
    queryFn: () => getPostsAction(params.page, params.limit),
    staleTime: 60 * 1000,
    ...options,
  });
};
export const useGetCategory = () => {
  return useQuery({
    queryKey: blogKeys.getCategory(),
    queryFn: () => blogService.getAllCategory(),
    staleTime: 60 * 1000,

  });
};

export const useGetPostBySlug = (slug, initialData) => {
  return useQuery({
    queryKey: blogKeys.postBySlug(slug),
    queryFn: () => blogService.getPostBySlug(slug),
    enabled: Boolean(slug),
    initialData
  });
};

export const useCountViews = () => {
  return useMutation({
    mutationKey: blogKeys.countViews(),
    mutationFn: (post_id) => blogService.countViews(post_id),
  });
};


export const useSearchPosts = ({ keyword, page = 1, limit = 10 }) => {
  return useQuery({
    queryKey: blogKeys.search({ keyword, page, limit }),
    queryFn: () => blogService.searchByKeyword({ keyword, page, limit }),
    enabled: !!keyword?.trim(),
    keepPreviousData: true,
  });
}



  


  



export const useGetPostsByAuthor = (authorFirstname, params = {}, options = {}) => {
  return useQuery({
    queryKey: blogKeys.postsByAuthor(authorFirstname, params),
    queryFn: () => blogService.getPostsByAuthor(authorFirstname, params),
    enabled: !!authorFirstname,
    staleTime: 60 * 1000,
    ...options,
  });




  
};



export const useGetRecommendedPosts = (postId, params = {}, options = {}) => {
  return useQuery({
    queryKey: blogKeys.recommendedPosts(postId, params),
    queryFn: () => blogService.getRecommendedPosts(postId, params),
    enabled: !!postId,
    staleTime: 60 * 1000,
    ...options,
  });
};